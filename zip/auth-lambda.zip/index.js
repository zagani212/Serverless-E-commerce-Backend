import jwt from "jsonwebtoken";
import jwkToPem from "jwk-to-pem";
import axios from "axios";

const REGION = process.env.REGION;
const USER_POOL_ID = process.env.USER_POOL_ID;

let pems = null;

// 🔹 Load JWKS and cache it
const getPems = async () => {
    if (pems) return pems;

    const url = `https://cognito-idp.${REGION}.amazonaws.com/${USER_POOL_ID}/.well-known/jwks.json`;
    const { data } = await axios.get(url);

    pems = {};
    for (const key of data.keys) {
        pems[key.kid] = jwkToPem(key);
    }

    return pems;
};

export const handler = async (event) => {
    try {
        const token = event.headers?.Authorization?.split(" ")[1];
        const userIdHeader = event.headers?.["x-user-id"];

        if (!token || !userIdHeader) {
            return generatePolicy("Deny", event.methodArn);
        }

        const decoded = jwt.decode(token, { complete: true });

        if (!decoded) {
            return generatePolicy("Deny", event.methodArn);
        }

        const pems = await getPems();
        const pem = pems[decoded.header.kid];

        if (!pem) {
            return generatePolicy("Deny", event.methodArn);
        }

        // 🔐 Verify token
        const verified = jwt.verify(token, pem, {
            issuer: `https://cognito-idp.${REGION}.amazonaws.com/${USER_POOL_ID}`
        });

        // 🔥 Your logic: compare sub with x-user-id
        if (verified.sub !== userIdHeader) {
            return generatePolicy("Deny", event.methodArn);
        }

        return generatePolicy("Allow", event.methodArn, verified);

    } catch (error) {
        console.error("Authorization error:", error);
        return generatePolicy("Deny", event.methodArn);
    }
};

// 🔹 IAM Policy generator
const generatePolicy = (effect, resource, user) => {
    return {
        principalId: user?.sub || "user",
        policyDocument: {
            Version: "2012-10-17",
            Statement: [
                {
                    Action: "execute-api:Invoke",
                    Effect: effect,
                    Resource: resource
                }
            ]
        },
        context: user
            ? {
                userId: user.sub,
                username: user.username
            }
            : {}
    };
};